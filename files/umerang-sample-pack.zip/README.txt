Umerang Lab sample pack

This zip exists so the file_download event can be tested.
It contains the catalog events as CSV. Test data only.
